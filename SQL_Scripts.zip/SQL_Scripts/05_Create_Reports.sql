USE EmployeeAttendanceDB;
GO

CREATE OR ALTER PROCEDURE dbo.usp_Daily_Attendance_Report
    @AttendanceDate DATE
AS
BEGIN
    SET NOCOUNT ON;

    SELECT e.EmployeeCode,
           e.EmployeeName,
           e.Department,
           a.AttendanceDate,
           a.LoginTime,
           a.LogoutTime,
           a.WorkingHours,
           CASE
               WHEN a.AttendanceID IS NULL THEN 'Absent / No punch recorded'
               WHEN a.LogoutTime IS NULL THEN 'Currently logged in'
               ELSE 'Completed'
           END AS SessionStatus
    FROM dbo.Employees e
    LEFT JOIN dbo.EmployeeAttendance a
        ON a.EmployeeID = e.EmployeeID
       AND a.AttendanceDate = @AttendanceDate
    WHERE e.IsActive = 1
    ORDER BY e.EmployeeCode, a.LoginTime;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_Monthly_Attendance_Report
    @Year INT,
    @Month INT
AS
BEGIN
    SET NOCOUNT ON;

    IF @Month NOT BETWEEN 1 AND 12
        THROW 50007, 'Month must be between 1 and 12.', 1;

    DECLARE @StartDate DATE = DATEFROMPARTS(@Year, @Month, 1);
    DECLARE @EndDate DATE = DATEADD(MONTH, 1, @StartDate);

    SELECT e.EmployeeCode,
           e.EmployeeName,
           e.Department,
           COUNT(a.AttendanceID) AS AttendanceSessions,
           COUNT(DISTINCT a.AttendanceDate) AS DaysWithPunches,
           CAST(SUM(COALESCE(a.WorkingHours, 0)) AS DECIMAL(10,2)) AS TotalCompletedHours,
           SUM(CASE WHEN a.LogoutTime IS NULL THEN 1 ELSE 0 END) AS OpenSessions
    FROM dbo.Employees e
    LEFT JOIN dbo.EmployeeAttendance a
        ON a.EmployeeID = e.EmployeeID
       AND a.AttendanceDate >= @StartDate
       AND a.AttendanceDate < @EndDate
    WHERE e.IsActive = 1
    GROUP BY e.EmployeeCode, e.EmployeeName, e.Department
    ORDER BY e.EmployeeCode;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_Employee_Attendance_History
    @EmployeeCode VARCHAR(20),
    @FromDate DATE,
    @ToDate DATE
AS
BEGIN
    SET NOCOUNT ON;

    IF @FromDate IS NULL OR @ToDate IS NULL OR @FromDate > @ToDate
        THROW 50008, 'Provide a valid date range.', 1;

    SELECT e.EmployeeCode,
           e.EmployeeName,
           a.AttendanceDate,
           a.LoginTime,
           a.LogoutTime,
           a.WorkingHours
    FROM dbo.Employees e
    INNER JOIN dbo.EmployeeAttendance a ON a.EmployeeID = e.EmployeeID
    WHERE e.EmployeeCode = @EmployeeCode
      AND a.AttendanceDate BETWEEN @FromDate AND @ToDate
    ORDER BY a.LoginTime;
END;
GO
