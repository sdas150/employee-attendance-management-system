USE EmployeeAttendanceDB;
GO

CREATE OR ALTER PROCEDURE dbo.usp_Employee_Login
    @EmployeeCode VARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @EmployeeID INT;
    DECLARE @PunchTime DATETIME2(0) = SYSDATETIME();

    BEGIN TRY
        BEGIN TRANSACTION;

        SELECT @EmployeeID = EmployeeID
        FROM dbo.Employees WITH (UPDLOCK, HOLDLOCK)
        WHERE EmployeeCode = @EmployeeCode
          AND IsActive = 1;

        IF @EmployeeID IS NULL
            THROW 50001, 'Employee code is invalid or employee is inactive.', 1;

        IF EXISTS
        (
            SELECT 1
            FROM dbo.EmployeeAttendance WITH (UPDLOCK, HOLDLOCK)
            WHERE EmployeeID = @EmployeeID
              AND LogoutTime IS NULL
        )
            THROW 50002, 'Employee already has an open attendance session.', 1;

        INSERT INTO dbo.EmployeeAttendance
            (EmployeeID, LoginTime, AttendanceDate)
        VALUES
            (@EmployeeID, @PunchTime, CONVERT(date, @PunchTime));

        COMMIT TRANSACTION;

        SELECT 'Login successful' AS Message,
               @EmployeeCode AS EmployeeCode,
               @PunchTime AS LoginTime;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_Employee_Logout
    @EmployeeCode VARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @EmployeeID INT;
    DECLARE @PunchTime DATETIME2(0) = SYSDATETIME();

    BEGIN TRY
        BEGIN TRANSACTION;

        SELECT @EmployeeID = EmployeeID
        FROM dbo.Employees WITH (UPDLOCK, HOLDLOCK)
        WHERE EmployeeCode = @EmployeeCode
          AND IsActive = 1;

        IF @EmployeeID IS NULL
            THROW 50003, 'Employee code is invalid or employee is inactive.', 1;

        DECLARE @OpenAttendanceID BIGINT;
        DECLARE @LoginTime DATETIME2(0);

        SELECT TOP (1)
            @OpenAttendanceID = AttendanceID,
            @LoginTime = LoginTime
        FROM dbo.EmployeeAttendance WITH (UPDLOCK, HOLDLOCK)
        WHERE EmployeeID = @EmployeeID
          AND LogoutTime IS NULL
        ORDER BY LoginTime DESC, AttendanceID DESC;

        IF @OpenAttendanceID IS NULL
            THROW 50004, 'No open attendance session found for this employee.', 1;

        UPDATE dbo.EmployeeAttendance
        SET LogoutTime = @PunchTime,
            WorkingHours = CAST(DATEDIFF_BIG(SECOND, @LoginTime, @PunchTime) / 3600.0 AS DECIMAL(10,2))
        WHERE AttendanceID = @OpenAttendanceID;

        COMMIT TRANSACTION;

        SELECT 'Logout successful' AS Message,
               @EmployeeCode AS EmployeeCode,
               @PunchTime AS LogoutTime,
               CAST(DATEDIFF_BIG(SECOND, @LoginTime, @PunchTime) / 3600.0 AS DECIMAL(10,2)) AS WorkingHours;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_Add_Employee
    @EmployeeCode VARCHAR(20),
    @EmployeeName NVARCHAR(100),
    @Department NVARCHAR(50) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF NULLIF(LTRIM(RTRIM(@EmployeeCode)), '') IS NULL
        THROW 50005, 'Employee code is required.', 1;
    IF NULLIF(LTRIM(RTRIM(@EmployeeName)), '') IS NULL
        THROW 50006, 'Employee name is required.', 1;

    INSERT INTO dbo.Employees (EmployeeCode, EmployeeName, Department)
    VALUES (@EmployeeCode, @EmployeeName, @Department);

    SELECT SCOPE_IDENTITY() AS NewEmployeeID,
           'Employee created successfully' AS Message;
END;
GO
