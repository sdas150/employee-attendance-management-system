USE EmployeeAttendanceDB;
GO

/* Safe to run repeatedly: inserts only employee codes not already present. */
INSERT INTO dbo.Employees (EmployeeCode, EmployeeName, Department)
SELECT v.EmployeeCode, v.EmployeeName, v.Department
FROM (VALUES
    ('EMP001', N'Rahul Sharma', N'IT'),
    ('EMP002', N'Amit Kumar', N'HR'),
    ('EMP003', N'Priya Das', N'Finance'),
    ('EMP004', N'Suresh Rao', N'IT'),
    ('EMP005', N'Neha Singh', N'Operations')
) AS v(EmployeeCode, EmployeeName, Department)
WHERE NOT EXISTS
(
    SELECT 1 FROM dbo.Employees e WHERE e.EmployeeCode = v.EmployeeCode
);
GO

SELECT EmployeeID, EmployeeCode, EmployeeName, Department, IsActive
FROM dbo.Employees
ORDER BY EmployeeID;
GO
