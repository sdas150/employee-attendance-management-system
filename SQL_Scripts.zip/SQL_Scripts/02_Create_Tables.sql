USE EmployeeAttendanceDB;
GO

IF OBJECT_ID(N'dbo.EmployeeAttendance', N'U') IS NOT NULL
    DROP TABLE dbo.EmployeeAttendance;
IF OBJECT_ID(N'dbo.Employees', N'U') IS NOT NULL
    DROP TABLE dbo.Employees;
GO

CREATE TABLE dbo.Employees
(
    EmployeeID   INT IDENTITY(1,1) CONSTRAINT PK_Employees PRIMARY KEY,
    EmployeeCode VARCHAR(20) NOT NULL CONSTRAINT UQ_Employees_EmployeeCode UNIQUE,
    EmployeeName NVARCHAR(100) NOT NULL,
    Department   NVARCHAR(50) NULL,
    IsActive     BIT NOT NULL CONSTRAINT DF_Employees_IsActive DEFAULT (1),
    CreatedAt    DATETIME2(0) NOT NULL CONSTRAINT DF_Employees_CreatedAt DEFAULT (SYSDATETIME())
);
GO

CREATE TABLE dbo.EmployeeAttendance
(
    AttendanceID  BIGINT IDENTITY(1,1) CONSTRAINT PK_EmployeeAttendance PRIMARY KEY,
    EmployeeID    INT NOT NULL,
    LoginTime     DATETIME2(0) NOT NULL,
    LogoutTime    DATETIME2(0) NULL,
    AttendanceDate DATE NOT NULL,
    WorkingHours  DECIMAL(10,2) NULL,
    CreatedAt     DATETIME2(0) NOT NULL CONSTRAINT DF_Attendance_CreatedAt DEFAULT (SYSDATETIME()),
    CONSTRAINT FK_Attendance_Employees FOREIGN KEY (EmployeeID)
        REFERENCES dbo.Employees(EmployeeID),
    CONSTRAINT CK_Attendance_TimeOrder CHECK (LogoutTime IS NULL OR LogoutTime >= LoginTime),
    CONSTRAINT CK_Attendance_WorkingHours CHECK (WorkingHours IS NULL OR WorkingHours >= 0)
);
GO

/* Enforces at most one open attendance session per employee, even under concurrent requests. */
CREATE UNIQUE INDEX UX_Attendance_OneOpenSessionPerEmployee
ON dbo.EmployeeAttendance(EmployeeID)
WHERE LogoutTime IS NULL;
GO

CREATE INDEX IX_Attendance_Date_Employee
ON dbo.EmployeeAttendance(AttendanceDate, EmployeeID)
INCLUDE (LoginTime, LogoutTime, WorkingHours);
GO
