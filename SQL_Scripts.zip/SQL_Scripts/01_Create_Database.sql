/* Run this script while connected to master. */
IF DB_ID(N'EmployeeAttendanceDB') IS NULL
BEGIN
    CREATE DATABASE EmployeeAttendanceDB;
END;
GO
USE EmployeeAttendanceDB;
GO
