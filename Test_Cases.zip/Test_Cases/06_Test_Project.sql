USE EmployeeAttendanceDB;
GO

/* Test 1: View employees */
SELECT * FROM dbo.Employees ORDER BY EmployeeCode;
GO

/* Test 2: Punch in EMP001 */
EXEC dbo.usp_Employee_Login @EmployeeCode = 'EMP001';
GO

/* Test 3: Try this immediately again. Expected: error 50002 (already logged in). */
-- EXEC dbo.usp_Employee_Login @EmployeeCode = 'EMP001';
GO

/* Test 4: Punch out EMP001 */
EXEC dbo.usp_Employee_Logout @EmployeeCode = 'EMP001';
GO

/* Test 5: Attendance data */
SELECT e.EmployeeCode, e.EmployeeName, a.AttendanceDate,
       a.LoginTime, a.LogoutTime, a.WorkingHours
FROM dbo.EmployeeAttendance a
JOIN dbo.Employees e ON e.EmployeeID = a.EmployeeID
ORDER BY a.AttendanceID DESC;
GO

/* Test 6: Daily report */
EXEC dbo.usp_Daily_Attendance_Report @AttendanceDate = CONVERT(date, SYSDATETIME());
GO

/* Test 7: Monthly report (change year/month as needed) */
EXEC dbo.usp_Monthly_Attendance_Report @Year = 2026, @Month = 11;
GO

/* Test 8: Employee history */
EXEC dbo.usp_Employee_Attendance_History
    @EmployeeCode = 'EMP001',
    @FromDate = '2026-11-01',
    @ToDate = '2026-11-30';
GO

/* Additional negative tests; uncomment one at a time to see expected errors. */
-- EXEC dbo.usp_Employee_Login @EmployeeCode = 'BAD001'; -- invalid employee
-- EXEC dbo.usp_Employee_Logout @EmployeeCode = 'EMP002'; -- no open session
GO
