# Project screenshots

Add genuine screenshots from your own SSMS execution here.

Suggested filenames:
- `01-employees-table.png`
- `02-punch-in-success.png`
- `03-punch-out-success.png`
- `04-daily-report.png`
- `05-monthly-report.png`

Do not add real employer or customer data.
